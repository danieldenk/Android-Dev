package RetrofitDeprecatedClasses;

public class Searchinfo {
    private float totalhits;


    // Getter Methods

    public float getTotalhits() {
        return totalhits;
    }

    // Setter Methods

    public void setTotalhits(float totalhits) {
        this.totalhits = totalhits;
    }
}
