package RetrofitDeprecatedClasses;

public class Continue {
    private float sroffset;
    private String aContinue;


    // Getter Methods

    public float getSroffset() {
        return sroffset;
    }

    public String getContinue() {
        return aContinue;
    }

    // Setter Methods

    public void setSroffset(float sroffset) {
        this.sroffset = sroffset;
    }

    public void setContinue(String aContinue) {
        this.aContinue = aContinue;
    }
}
