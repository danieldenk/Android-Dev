package RetrofitDeprecatedClasses;

class SearchObject {
     int ns;
     String title;
     int pageid;
     int size;
     int wordcount;
     String snippet;
     String timestamp;
}
